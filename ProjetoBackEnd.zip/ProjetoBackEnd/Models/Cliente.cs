﻿using Microsoft.Build.Framework;
using System.ComponentModel.DataAnnotations;

namespace ProjetoBackEnd.Models
{
    public class Cliente
    {
        public int Id { get; set; }

        [System.ComponentModel.DataAnnotations.Required(ErrorMessage ="O nome precisa ser preenchido")]
        public string Nome { get; set; }

        [System.ComponentModel.DataAnnotations.Required(ErrorMessage = "O email precisa ser preenchido")]
        [RegularExpression(@"^[^@\s]+@[^@\s]+\.(com|org|net|gov)$", ErrorMessage = "Email inválido")]
        public string Email{ get; set; }

        [System.ComponentModel.DataAnnotations.Required(ErrorMessage = "O celular precisa ser preenchido")]
        [RegularExpression(@"^\s*(\d{2}|\d{0})[-. ]?(\d{5}|\d{4})[-. ]?(\d{4})[-. ]?\s*$", ErrorMessage = "Número de celular inválido")]
        public string Celular { get; set; }

    }
}
